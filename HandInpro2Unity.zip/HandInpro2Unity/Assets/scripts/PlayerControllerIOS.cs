﻿using UnityEngine;
using System.Collections;

public class PlayerControllerIOS : MonoBehaviour {

	public float speed;

	private Rigidbody rb;

	void Start ()
	{
		rb = GetComponent<Rigidbody>();
	}

	void FixedUpdate ()
	{
		float moveHorizontal = Input.acceleration.x;
		float moveVertical = Input.acceleration.z;

		Vector3 movement = new Vector3 (moveHorizontal, 0.0f, moveVertical);

		rb.Sleep ();
		int i = 0;

		if (i > Input.accelerationEventCount) {
			rb.Sleep ();

		}  else {
			rb.WakeUp ();
			rb.AddForce (movement * speed);

		}

	}

}
