﻿using UnityEngine;
using System.Collections;

public class menu : MonoBehaviour {

	public bool isStartNormal;
	public bool isStartIOS;
	public bool isQuit;

	void OnMouseUp(){
		if(isStartNormal)
		{
			Application.LoadLevel(1);
		}

		if(isStartIOS)
		{
			Application.LoadLevel(2);
		}

		if (isQuit)
		{
			Application.Quit();
		}
	} 
}
