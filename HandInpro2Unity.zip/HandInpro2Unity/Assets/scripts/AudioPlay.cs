﻿using UnityEngine;
using System.Collections;

namespace Vuforia{

public class AudioPlay : MonoBehaviour, ITrackableEventHandler{

		private TrackableBehaviour mTrackableBehaviour;
		private AudioSource audio;

	// Use this for initialization
	void Start () {
			audio = GetComponent<AudioSource>();
			mTrackableBehaviour = GetComponent<TrackableBehaviour>();

			if (mTrackableBehaviour) {
				mTrackableBehaviour.RegisterTrackableEventHandler (this);
			}
	}
	
		public void OnTrackableStateChanged(TrackableBehaviour.Status previousStatus, TrackableBehaviour.Status newStatus){

			if (newStatus == TrackableBehaviour.Status.DETECTED || newStatus == TrackableBehaviour.Status.TRACKED) {
				audio.Play();
			} else {
				audio.Stop();
			}

		}
}
}
