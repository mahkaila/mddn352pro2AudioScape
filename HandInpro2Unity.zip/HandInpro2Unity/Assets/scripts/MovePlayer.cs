﻿using UnityEngine;
using System.Collections;

namespace Vuforia
{
	public class MovePlayer : MonoBehaviour, ITrackableEventHandler{

		private TrackableBehaviour mTrackableBehaviour;
		public GameObject player;

		public float x;
		public float y;
		public float z;

		void Start(){

			player = GameObject.FindWithTag("Player");

			mTrackableBehaviour = GetComponent<TrackableBehaviour>();

			if(mTrackableBehaviour){

				mTrackableBehaviour.RegisterTrackableEventHandler(this);

			}
		}

		public void OnTrackableStateChanged(TrackableBehaviour.Status previousStatus, 
			TrackableBehaviour.Status newStatus){

			if (newStatus == TrackableBehaviour.Status.DETECTED || newStatus == TrackableBehaviour.Status.TRACKED) {
				player.transform.position = new Vector3 (x, y, z);
			}
		}
	}
}
